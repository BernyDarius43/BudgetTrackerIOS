import { useFonts } from 'expo-font';
import { Slot, useRouter } from 'expo-router';
import * as SplashScreen from 'expo-splash-screen';
import 'react-native-reanimated';
import { useColorScheme } from '@/hooks/useColorScheme';
import { Redirect } from 'expo-router';
import { AuthProvider, useAuth } from '../context/authContext/authContext';
import { View, ActivityIndicator, StyleSheet } from 'react-native';
import { useEffect } from 'react';

// Prevent the splash screen from auto-hiding before asset loading is complete.
SplashScreen.preventAutoHideAsync();

// // A small component to handle authentication redirection.
// function AuthHandler() {
//   const { userLoggedIn, loading } = useAuth();
//   const router = useRouter();

//   useEffect(() => {
//     if (!loading) {
//       const targetRoute = userLoggedIn ? '/(tabs)/home-user' : '/home';
//       router.replace(targetRoute);
//     }
//   }, [loading, userLoggedIn, router]);

//   // Optionally, show a loader while waiting.
//   return (
//     <View style={styles.loaderContainer}>
//       <ActivityIndicator size="large" color="#3b82f6" />
//     </View>
//   );
// }

export default function RootLayout() {
  return (
    <AuthProvider>
      {/* <AuthHandler /> */}
      <Slot />
    </AuthProvider>
  );
}

const styles = StyleSheet.create({
  loaderContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
});
